' //css_ref System
' //css_ref System.Windows.Forms
Imports System
Imports System.Windows.Forms

Module Module1
    Sub Main()
        Console.WriteLine("Hello World! (VB)")
        MessageBox.Show("")
    End Sub
End Module









REM dim line = new Line()
REM Console.WriteLine(line.Length)

























REM Public Class Line

REM Private mstrLine As String

REM Property Line() As String
REM Get
REM Return mstrLine
REM End Get
REM Set(ByVal Value As String)
REM mstrLine = Value
REM End Set
REM End Property

REM ReadOnly Property Length() As Integer
REM Get
REM Return mstrLine.Length
REM End Get
REM End Property

REM End Class


' move the following line on top of the document if you want to use CSSCodeProvider configured in the code (not globally).
' //css_args /provider:CSSCodeProvider.v4.0.dll