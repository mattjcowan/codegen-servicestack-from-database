using System;

class Script
{
	[STAThread]
	static public void Main(string[] args)
	{
		Console.WriteLine("Hello World");
	}
}

